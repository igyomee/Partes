require("dotenv").config();

const express = require("express");
const path = require("path");
const { google } = require("googleapis");

const app = express();
const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, "public");

const SHEET_HEADERS = [
  "Timestamp Guardado",
  "Mes",
  "Fecha Trabajo",
  "Cliente",
  "Instalación",
  "Operario",
  "DNI Operario",
  "Tipo Servicio",
  "Año OT",
  "OT",
  "Hora Entrada",
  "Hora Salida",
  "Horas Jornada",
  "Horas Adicionales",
  "Tiempo Comida",
  "Almuerzo",
  "Comida",
  "Total Horas Declaradas",
  "Total Horas Reales",
  "Descripción Trabajo",
  "Observaciones",
  "KM",
  "Prima",
  "Busca",
  "Nocturnidad",
  "Firma Técnico",
  "Firma Cliente",
  "Estado Procesado",
  "Fecha Procesado",
  "PDF Generado",
  "Error Procesamiento",
];

const PROCESSING_PENDING = "Pendiente";

app.use(express.json({ limit: "1mb" }));
app.use(express.static(PUBLIC_DIR));

function cleanText(value, maxLength = 5000) {
  return String(value ?? "")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "")
    .trim()
    .slice(0, maxLength);
}

function cleanBoolean(value) {
  return Boolean(value);
}

function cleanNumberText(value) {
  const text = cleanText(value, 30).replace(",", ".");
  if (!text) return "";
  const number = Number(text);
  return Number.isFinite(number) ? String(number) : "";
}

function parseHours(value) {
  const text = cleanNumberText(value);
  if (!text) return 0;
  return Number(text);
}

function parseTimeToMinutes(value) {
  const text = cleanText(value, 10);
  const match = text.match(/^([01]\d|2[0-3]):([0-5]\d)$/);
  if (!match) return null;
  return Number(match[1]) * 60 + Number(match[2]);
}

function hoursBetween(start, end) {
  const startMinutes = parseTimeToMinutes(start);
  const endMinutes = parseTimeToMinutes(end);
  if (startMinutes === null || endMinutes === null) return null;
  let diff = endMinutes - startMinutes;
  if (diff < 0) diff += 24 * 60;
  return diff / 60;
}

function monthNameFromDate(date) {
  const text = cleanText(date, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return "";
  return text.slice(0, 7);
}

function getSheetsClient() {
  const spreadsheetId = cleanText(process.env.GOOGLE_SHEETS_SPREADSHEET_ID);
  const email = cleanText(process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL);
  const privateKey = String(process.env.GOOGLE_PRIVATE_KEY || "").replace(/\\n/g, "\n");

  if (!spreadsheetId || !email || !privateKey) {
    const missing = [
      !spreadsheetId && "GOOGLE_SHEETS_SPREADSHEET_ID",
      !email && "GOOGLE_SERVICE_ACCOUNT_EMAIL",
      !privateKey && "GOOGLE_PRIVATE_KEY",
    ].filter(Boolean);
    const error = new Error(`Faltan variables de entorno: ${missing.join(", ")}`);
    error.status = 500;
    throw error;
  }

  const auth = new google.auth.JWT({
    email,
    key: privateKey,
    scopes: ["https://www.googleapis.com/auth/spreadsheets"],
  });

  return {
    spreadsheetId,
    sheets: google.sheets({ version: "v4", auth }),
  };
}

function normalizePart(raw) {
  const tecnicos = Array.isArray(raw.tecnicos) ? raw.tecnicos : [];
  const normalizedTecnicos = tecnicos
    .map((item) => ({
      nombre: cleanText(item?.nombre ?? item?.name ?? item, 120),
      dni: cleanText(item?.dni, 30).toUpperCase(),
    }))
    .filter((item) => item.nombre || item.dni);

  return {
    fecha: cleanText(raw.fecha, 10),
    tecnicos: normalizedTecnicos,
    cliente: cleanText(raw.cliente, 200),
    instalacion: cleanText(raw.instalacion ?? raw.direccion, 300),
    direccion: cleanText(raw.direccion ?? raw.instalacion, 300),
    tipoServicio: cleanText(raw.tipoServicio, 80),
    anioOt: cleanText(raw.anioOt, 20),
    ot: cleanText(raw.ot, 80),
    horaInicio: cleanText(raw.horaInicio, 10),
    horaFinal: cleanText(raw.horaFinal, 10),
    horasJornada: cleanNumberText(raw.horasJornada),
    horasUrgencia: cleanNumberText(raw.horasUrgencia),
    descripcion: cleanText(raw.descripcion, 5000),
    observaciones: cleanText(raw.observaciones, 5000),
    almuerzo: cleanBoolean(raw.almuerzo),
    comida: cleanBoolean(raw.comida),
    tiempoComida: cleanText(raw.tiempoComida, 10),
    km: cleanNumberText(raw.km),
    prima: cleanText(raw.prima, 50),
    busca: cleanBoolean(raw.busca),
    nocturnidad: cleanBoolean(raw.nocturnidad),
  };
}

function validatePart(part) {
  if (!part.fecha || !/^\d{4}-\d{2}-\d{2}$/.test(part.fecha)) {
    return "La fecha de trabajo es obligatoria.";
  }
  if (!part.tecnicos.length) {
    return "Debe indicarse al menos un técnico.";
  }
  const missingDni = part.tecnicos.find((tecnico) => !tecnico.nombre || !tecnico.dni);
  if (missingDni) {
    return "Cada técnico debe tener nombre y DNI.";
  }
  if (!part.cliente) {
    return "El cliente es obligatorio.";
  }
  if (parseTimeToMinutes(part.horaInicio) === null) {
    return "La hora de entrada no es válida.";
  }
  if (parseTimeToMinutes(part.horaFinal) === null) {
    return "La hora de salida no es válida.";
  }
  if (!part.horasJornada) {
    return "Las horas de jornada son obligatorias.";
  }
  if (!part.descripcion) {
    return "La descripción de trabajo es obligatoria.";
  }

  const realHours = hoursBetween(part.horaInicio, part.horaFinal);
  const declaredHours = getDeclaredHours(part);
  if (realHours !== null && Math.abs(realHours - declaredHours) > 0.25) {
    return `Las horas no cuadran: entre entrada y salida hay ${realHours.toFixed(2)} h, pero has declarado ${declaredHours.toFixed(2)} h.`;
  }

  return "";
}

function getDeclaredHours(part) {
  const foodHours = Number(part.tiempoComida || 0) / 60;
  return parseHours(part.horasJornada) + parseHours(part.horasUrgencia) + foodHours;
}

async function ensureMonthlySheet(sheets, spreadsheetId, monthName) {
  const spreadsheet = await sheets.spreadsheets.get({ spreadsheetId });
  const existingSheet = spreadsheet.data.sheets?.find((sheet) => sheet.properties?.title === monthName);

  if (!existingSheet) {
    await sheets.spreadsheets.batchUpdate({
      spreadsheetId,
      requestBody: {
        requests: [{ addSheet: { properties: { title: monthName } } }],
      },
    });
    await sheets.spreadsheets.values.update({
      spreadsheetId,
      range: `'${monthName}'!A1`,
      valueInputOption: "RAW",
      requestBody: { values: [SHEET_HEADERS] },
    });
    return;
  }

  const headerResponse = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range: `'${monthName}'!A1:${columnName(SHEET_HEADERS.length)}1`,
  });
  const currentHeaders = headerResponse.data.values?.[0] || [];
  if (SHEET_HEADERS.some((header, index) => currentHeaders[index] !== header)) {
    await sheets.spreadsheets.values.update({
      spreadsheetId,
      range: `'${monthName}'!A1`,
      valueInputOption: "RAW",
      requestBody: { values: [SHEET_HEADERS] },
    });
  }
}

function columnName(index) {
  let value = index;
  let name = "";
  while (value > 0) {
    const mod = (value - 1) % 26;
    name = String.fromCharCode(65 + mod) + name;
    value = Math.floor((value - mod) / 26);
  }
  return name;
}

function buildRows(part, monthName) {
  const timestamp = new Date().toISOString();
  const declaredHours = getDeclaredHours(part).toFixed(2);
  const realHours = hoursBetween(part.horaInicio, part.horaFinal)?.toFixed(2) || "";

  return part.tecnicos.map((tecnico) => [
    timestamp,
    monthName,
    part.fecha,
    part.cliente,
    part.instalacion,
    tecnico.nombre,
    tecnico.dni,
    part.tipoServicio,
    part.anioOt,
    part.ot,
    part.horaInicio,
    part.horaFinal,
    part.horasJornada,
    part.horasUrgencia || "0",
    part.tiempoComida,
    part.almuerzo ? "Si" : "No",
    part.comida ? "Si" : "No",
    declaredHours,
    realHours,
    part.descripcion,
    part.observaciones,
    part.km,
    part.prima,
    part.busca ? "Si" : "No",
    part.nocturnidad ? "Si" : "No",
    "",
    "",
    PROCESSING_PENDING,
    "",
    "",
    "",
  ]);
}

async function appendPartToSheets(part) {
  const monthName = monthNameFromDate(part.fecha);
  const { sheets, spreadsheetId } = getSheetsClient();
  await ensureMonthlySheet(sheets, spreadsheetId, monthName);
  const rows = buildRows(part, monthName);

  await sheets.spreadsheets.values.append({
    spreadsheetId,
    range: `'${monthName}'!A1`,
    valueInputOption: "USER_ENTERED",
    insertDataOption: "INSERT_ROWS",
    requestBody: { values: rows },
  });

  return { monthName, rowsAdded: rows.length };
}

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    storage: "google-sheets",
    spreadsheetConfigured: Boolean(process.env.GOOGLE_SHEETS_SPREADSHEET_ID),
    driveFolderConfigured: Boolean(process.env.GOOGLE_DRIVE_FOLDER_ID),
  });
});

app.post("/api/partes", async (req, res) => {
  try {
    const part = normalizePart(req.body || {});
    const validationError = validatePart(part);
    if (validationError) {
      res.status(400).json({ error: validationError });
      return;
    }

    const result = await appendPartToSheets(part);
    res.status(201).json({
      ok: true,
      message: "Parte guardado en Google Sheets.",
      month: result.monthName,
      rowsAdded: result.rowsAdded,
    });
  } catch (error) {
    console.error(error);
    res.status(error.status || 500).json({
      error: error.status === 500
        ? error.message
        : "No se ha podido guardar el parte.",
    });
  }
});

app.get("/api/partes", async (req, res) => {
  res.json({
    message: "Los partes se guardan en Google Sheets. Usa el endpoint POST /api/partes para insertar nuevas filas.",
    pendingState: PROCESSING_PENDING,
  });
});

app.use((req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "index.html"));
});

app.listen(PORT, () => {
  console.log(`Partes digitales listo en http://localhost:${PORT}`);
});
