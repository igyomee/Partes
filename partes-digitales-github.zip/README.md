# Partes digitales

Aplicacion web para capturar partes de trabajo de tecnicos y guardar los datos en Google Sheets. La app ya no usa `data/partes.json` como almacenamiento principal.

## Requisitos

- Node.js 18 o superior.
- Un Google Sheets creado.
- Una cuenta de servicio de Google Cloud con acceso a Google Sheets API.

## Instalacion

```bash
npm install
```

## Configuracion de Google Cloud

1. Entra en Google Cloud Console.
2. Crea un proyecto o usa uno existente.
3. Activa la API de Google Sheets.
4. Crea una cuenta de servicio.
5. Crea una clave privada JSON para esa cuenta de servicio.
6. Copia el email de la cuenta de servicio.
7. Abre tu Google Sheets y compartelo con ese email como editor.

## Variables de entorno

Crea un archivo `.env` en la raiz del proyecto usando `.env.example` como plantilla:

```env
GOOGLE_SHEETS_SPREADSHEET_ID=tu_id_de_google_sheets
GOOGLE_SERVICE_ACCOUNT_EMAIL=cuenta-servicio@proyecto.iam.gserviceaccount.com
GOOGLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n"
GOOGLE_DRIVE_FOLDER_ID=
PORT=3000
```

Notas:

- `GOOGLE_SHEETS_SPREADSHEET_ID` es el ID que aparece en la URL del documento de Google Sheets.
- `GOOGLE_PRIVATE_KEY` debe conservar los saltos de linea como `\n`.
- `GOOGLE_DRIVE_FOLDER_ID` queda preparado para una futura fase de PDFs en Drive, pero ahora no se usa.
- No subas `.env` a GitHub.

## Ejecutar en local

```bash
npm start
```

Abre:

```text
http://localhost:3000
```

## Funcionamiento

Al guardar un parte:

- El frontend envia los datos a `POST /api/partes`.
- El backend valida los campos obligatorios.
- Se crea o usa una hoja mensual con nombre `YYYY-MM`.
- Si la hoja mensual no existe, se crea y se añaden encabezados.
- Si hay varios operarios, se inserta una fila por operario.
- Cada fila queda con `Estado Procesado = Pendiente`.

Esto deja el Google Sheets preparado para que un agente posterior lea solo las filas pendientes, genere PDFs, escriba enlaces, cambie el estado a `Procesado` y rellene errores si los hay.

## Endpoints

- `GET /api/health`: comprueba que el servidor funciona y si hay configuracion de Sheets.
- `POST /api/partes`: guarda un parte en Google Sheets.
- `GET /api/partes`: endpoint informativo para pruebas.

## Encabezados creados en cada hoja mensual

```text
Timestamp Guardado
Mes
Fecha Trabajo
Cliente
Instalación
Operario
DNI Operario
Tipo Servicio
Año OT
OT
Hora Entrada
Hora Salida
Horas Jornada
Horas Adicionales
Tiempo Comida
Almuerzo
Comida
Total Horas Declaradas
Total Horas Reales
Descripción Trabajo
Observaciones
KM
Prima
Busca
Nocturnidad
Firma Técnico
Firma Cliente
Estado Procesado
Fecha Procesado
PDF Generado
Error Procesamiento
```

Las columnas `Firma Técnico` y `Firma Cliente` se dejan vacias porque el flujo actual sustituye firmas por DNI del tecnico.

## Despliegue en Render

1. Sube el proyecto a GitHub sin `.env`.
2. Crea un nuevo Web Service en Render.
3. Conecta el repositorio.
4. Usa:

```text
Build Command: npm install
Start Command: npm start
```

5. Configura en Render las variables:

```text
GOOGLE_SHEETS_SPREADSHEET_ID
GOOGLE_SERVICE_ACCOUNT_EMAIL
GOOGLE_PRIVATE_KEY
GOOGLE_DRIVE_FOLDER_ID
```

Render asigna `PORT` automaticamente; el servidor usa `process.env.PORT`.
