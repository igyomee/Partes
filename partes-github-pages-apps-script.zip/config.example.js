window.PARTES_CONFIG = {
  APPS_SCRIPT_URL: "https://script.google.com/macros/s/TU_ID_DE_DEPLOYMENT/exec",
};
